package classes.Atendimento;

public class Consulta_Solicita_Exame {
    private Consulta id_consulta;
    private Exame id_exame;
    
    public Consulta getId_consulta() {
        return id_consulta;
    }
    public void setId_consulta(Consulta id_consulta) {
        this.id_consulta = id_consulta;
    }
    public Exame getId_exame() {
        return id_exame;
    }
    public void setId_exame(Exame id_exame) {
        this.id_exame = id_exame;
    }
    
}
