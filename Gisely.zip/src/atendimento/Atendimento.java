package atendimento;

import java.util.Scanner;

public class Atendimento {
    private int id_atendimento;
    private String tipo_atendimento;
    private String status_atendimento;
    private String data_hora_atendimento;

    public Atendimento(int id_atendimento, String tipo_atendimento, String status_atendimento, String data_hora_atendimento) {
        this.id_atendimento = id_atendimento;
        this.tipo_atendimento = tipo_atendimento;
        this.status_atendimento = status_atendimento;
        this.data_hora_atendimento = data_hora_atendimento;
    }

    public void solicitarDadosAtendimento() {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Digite o tipo de atendimento: ");
        this.tipo_atendimento = scanner.nextLine();

        System.out.print("Digite o status do atendimento: ");
        this.status_atendimento = scanner.nextLine();

        System.out.print("Digite a data e hora do atendimento (formato: dd/MM/yyyy HH:mm): ");
        this.data_hora_atendimento = scanner.nextLine();
    }


    public int getId_atendimento() {
        return id_atendimento;
    }

    public void setId_atendimento(int id_atendimento) {
        this.id_atendimento = id_atendimento;
    }

    public String getTipo_atendimento() {
        return tipo_atendimento;
    }

    public void setTipo_atendimento(String tipo_atendimento) {
        this.tipo_atendimento = tipo_atendimento;
    }

    public String getStatus_atendimento() {
        return status_atendimento;
    }

    public void setStatus_atendimento(String status_atendimento) {
        this.status_atendimento = status_atendimento;
    }

    public String getData_hora_atendimento() {
        return data_hora_atendimento;
    }

    public void setData_hora_atendimento(String data_hora_atendimento) {
        this.data_hora_atendimento = data_hora_atendimento;
    }
}
