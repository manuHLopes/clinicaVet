package atendimento;

import java.util.Scanner;

public class Servico extends Atendimento {
    private int id_servico;
    private String nome_servico;


    public Servico(int id_atendimento, String tipo_atendimento, String status_atendimento, String data_hora_atendimento, int id_servico, String nome_servico) {
        super(id_atendimento, tipo_atendimento, status_atendimento, data_hora_atendimento);
        this.id_servico = id_servico;
        this.nome_servico = nome_servico;
    }

    public void solicitarNomeServico() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite o nome do serviço: ");
        this.nome_servico = scanner.nextLine();
    }

    public int getId_servico() {
        return id_servico;
    }

    public void setId_servico(int id_servico) {
        this.id_servico = id_servico;
    }

    public String getNome_servico() {
        return nome_servico;
    }

    public void setNome_servico(String nome_servico) {
        this.nome_servico = nome_servico;
    }
}
