package atendimento;

import java.util.Scanner;

public class Servico_pertence_TipoServico {
    private int id_servico;
    private int id_tipo_servico;
    private double valor_total;

    // Construtor
    public Servico_pertence_TipoServico(int id_servico, int id_tipo_servico, double valor_total) {
        this.id_servico = id_servico;
        this.id_tipo_servico = id_tipo_servico;
        this.valor_total = valor_total;
    }

    public void solicitarValorTotal() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Digite o valor total: ");
        this.valor_total = scanner.nextDouble();
    }

    public int getId_servico() {
        return id_servico;
    }

    public void setId_servico(int id_servico) {
        this.id_servico = id_servico;
    }

    public int getId_tipo_servico() {
        return id_tipo_servico;
    }

    public void setId_tipo_servico(int id_tipo_servico) {
        this.id_tipo_servico = id_tipo_servico;
    }

    public double getValor_total() {
        return valor_total;
    }

    public void setValor_total(double valor_total) {
        this.valor_total = valor_total;
    }
}
